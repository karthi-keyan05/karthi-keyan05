from flask import Blueprint, render_template, request, flash

feedback_bp = Blueprint('feedback', __name__)

feedback_list = []

@feedback_bp.route('/', methods=['GET', 'POST'])
def feedback():
    if request.method == 'POST':
        name = request.form['name']
        message = request.form['message']
        feedback_list.append({"name": name, "message": message})
        flash('Feedback submitted!', 'success')
    return render_template('feedback.html', feedbacks=feedback_list)
