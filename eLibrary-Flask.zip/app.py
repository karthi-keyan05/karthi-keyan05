from flask import Flask, render_template, redirect, url_for, session
from auth import auth_bp
from book import book_bp
from feedback import feedback_bp

app = Flask(__name__)
app.secret_key = 'your_secret_key'

app.register_blueprint(auth_bp, url_prefix="/auth")
app.register_blueprint(book_bp, url_prefix="/books")
app.register_blueprint(feedback_bp, url_prefix="/feedback")

@app.route('/')
def home():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
