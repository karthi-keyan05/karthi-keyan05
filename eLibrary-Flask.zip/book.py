from flask import Blueprint, render_template

book_bp = Blueprint('book', __name__)

books = [
    {"title": "The Great Gatsby", "author": "F. Scott Fitzgerald"},
    {"title": "To Kill a Mockingbird", "author": "Harper Lee"},
    {"title": "1984", "author": "George Orwell"},
]

@book_bp.route('/')
def list_books():
    return render_template('books.html', books=books)
