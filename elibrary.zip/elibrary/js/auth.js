document.getElementById('loginBtn').addEventListener('click', showLoginForm);
document.getElementById('registerBtn').addEventListener('click', showRegisterForm);